package com.codeforany.workout_fitness

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
